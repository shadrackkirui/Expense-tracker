# Expense Tracker (Ksh)

A simple expense tracker built with Vite + React + Tailwind CSS + React Router.
Data is stored in browser localStorage.

## Features
- Add expenses with description and amount (Ksh).
- Set a budget and see remaining balance.
- Delete expenses.
- Persistent storage in browser.

## Tech Stack
- React 18
- Vite 5
- Tailwind CSS 3.4.17
- React Router 6
- lucide-react icons

## Usage
```bash
npm install
npm run dev
```
